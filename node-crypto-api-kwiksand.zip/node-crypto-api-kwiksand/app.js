var restify = require('restify');
var plugins = require('restify-plugins');
var config = require('./config/config');

var appService =  require('./service/AppService');

// Server SETUP
var server = restify.createServer({
    name: "Node Crypto",
    version: "1.0.0"
});


var resp = function(res,data,next,code){
    res.header("Access-Control-Allow-Origin", "*");
    res.writeHead(code, {'Content-Type': 'application/json; charset=utf-8'});
    res.end(data);
    return next();
};

server.use(plugins.acceptParser(server.acceptable));
server.use(plugins.queryParser(
    {mapParams: true}
));
server.use(plugins.bodyParser(
    {mapParams: true}
));


server.listen(config.init_port, function () {
    console.log('%s listening at %s', server.name, server.url+config.app_base);
});


server.get(config.app_base+'/cryptopia', function (req, res, next) {
    if ('API_KEY' in req.params &&
        'API_SECRET' in req.params
    ) {
      var credentials = { 
        'API_KEY': req.params.API_KEY,
        'API_SECRET': req.params.API_SECRET
      } 
    
      appService.cryptopia_api_query("GetBalance", credentials, function(error, response, code){
          resp(res,response, next, code);
      });
    } else {
      resp(res, 'Cryptopia requires API_KEY and API_SECRET parameters', next, 400)
    }
});

server.get(config.app_base+'/bitstamp', function (req, res, next) {
    if ('CUSTOMER_ID' in req.params &&
        'API_KEY' in req.params &&
        'API_SECRET' in req.params
    ) {
      var credentials = { 
        'CUSTOMER_ID': req.params.CUSTOMER_ID,
        'API_KEY': req.params.API_KEY,
        'API_SECRET': req.params.API_SECRET
      } 
    
      appService.bitstamp_api_query(credentials, function(error, response, code){
  	resp(res,response, next, code);
      });
    } else {
      resp(res, 'Bitstamp requires CUSTOMER_ID, API_KEY and API_SECRET parameters', next, 400)
    }
});
