var Config = {
    CRYPTOPIA_API_KEY: "b08ce14d2e9c4956ad4a2bee3ba8f4bc",
    CRYPTOPIA_API_SECRET: "j4Ni5TBpzp9TmcKu3dhy68HkKw7SR6lRT+Xq6D9lZiU=",
    BITSTAMP_API_KEY: "CaCKaRM9BDEi1pu08u9d465tjekDlJLB",
    BITSTAMP_API_SECRET: "WBUJWm13DpyiEnwau7W9zuMGcfycGu5G",
    CUSTOMER_ID: "730896",
    init_port: 3233,
    app_base:  "/cryptobalance"
};

module.exports = Config;
