import hmac
import hashlib
import requests
import json

message = '111111' + '730896' + 'CaCKaRM9BDEi1pu08u9d465tjekDlJLB'
signature = hmac.new(
    "WBUJWm13DpyiEnwau7W9zuMGcfycGu5G",
    msg=message,
    digestmod=hashlib.sha256
).hexdigest().upper()
post_data = {"key": "CaCKaRM9BDEi1pu08u9d465tjekDlJLB",
                        	"signature": signature,
                        	"nonce": '111111'};


r = requests.post("https://www.bitstamp.net/api/v2/balance/", data = post_data )
response = r.text
print "( Response ): " + response

print signature
