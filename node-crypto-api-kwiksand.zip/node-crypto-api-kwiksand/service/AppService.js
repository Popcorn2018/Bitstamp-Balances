var config = require('../config/config');
var https = require('https');
var crypto = require('crypto');
var request = require('request');

var AppService = {
    cryptopia_api_query: function (method, credentials, cb) {
	var params = {};
	var public_set = [ "GetCurrencies", "GetTradePairs", "GetMarkets", "GetMarket", "GetMarketHistory", "GetMarketOrders" ];
	var private_set = [ "GetBalance", "GetDepositAddress", "GetOpenOrders", "GetTradeHistory", "GetTransactions", "SubmitTrade", "CancelTrade", "SubmitTip" ];
	var host_name = 'www.cryptopia.co.nz';
	var uri = '/Api/' + method;
	if ( public_set.indexOf( method ) > -1 ) {
	    if ( params ) uri += "/" + params.join('/');
	    var options = {
		host: host_name,
		path: uri
	    };
	    callback = function(response) {
		var str = '';
		response.on('data', function (chunk) {
		    str += chunk;
		});
		response.on('end', function () {
		    return cb(null, str);
		});
	    };
	    https.request(options, callback).end();
	} else if (  private_set.indexOf( method ) > -1 ) {
	    var nonce = Math.floor(new Date().getTime() / 1000);
	    var md5 = crypto.createHash('md5').update( JSON.stringify( params ) ).digest();
	    var requestContentBase64String = md5.toString('base64');
	    var signature = credentials.API_KEY + "POST" + encodeURIComponent( 'https://' + host_name + uri ).toLowerCase() + nonce + requestContentBase64String;
	    var hmacsignature = crypto.createHmac('sha256', new Buffer( credentials.API_SECRET, "base64" ) ).update( signature ).digest().toString('base64');
	    var header_value = "amx " + credentials.API_KEY + ":" + hmacsignature + ":" + nonce;
	    var headers = { 'Authorization': header_value, 'Content-Type':'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(JSON.stringify(params)) };
	    var options = {
		host: host_name,
		path: uri,
		method: 'POST',
		headers: headers
	    };
	    callback = function(response) {
		var str = '';
		response.on('data', function (chunk) {
		    str += chunk;
		});
		response.on('end', function () {
		    return cb(null, str, 200);
		});
	    };
	    var req = https.request(options, callback);
	    req.write( JSON.stringify( params ) );
	    req.end();
	}
    },

    bitstamp_api_query: function (credentials, cb) {
        
	var nonce = Math.floor(new Date().getTime() / 1000);
	var signature = nonce + credentials.CUSTOMER_ID + credentials.API_KEY;

	var hmacsignature = crypto.createHmac('sha256', credentials.API_SECRET ).update( signature ).digest().toString('hex').toUpperCase();

	var options = {
	    url: "https://www.bitstamp.net/api/v2/balance/",
	    method: "post",
	    form: {
		key: credentials.API_KEY,
		signature: hmacsignature,
		nonce: nonce
	    }
	};

	request(options, function (error, response, body) {
	    if(!error){
	        return cb(null, body, 200)
	    }
	});
    }
};

module.exports = AppService;
