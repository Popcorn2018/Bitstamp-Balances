var request = require('request');
var config = require('./config/config');
var crypto = require('crypto');

var nonce = Math.floor(new Date().getTime() / 1000);
var signature = nonce + config.CUSTOMER_ID + config.BITSTAMP_API_KEY;

var hmacsignature = crypto.createHmac('sha256', config.BITSTAMP_API_SECRET ).update( signature ).digest().toString('hex').toUpperCase();

var options = {
    url: "https://www.bitstamp.net/api/v2/balance/",
    method: "post",
    form: {
	key: config.BITSTAMP_API_KEY,
	signature: hmacsignature,
	nonce: nonce
    }
};

request(options, function (error, response, body) {
    console.log('Error ', error)
    console.log('Body ', body)
});